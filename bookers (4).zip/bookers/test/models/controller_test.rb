require 'test_helper'

class ControllerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
